package edu.eci.cvds;

/**
 * Hello world!
 *
 */
public class App
{
    public static void main( String[] args )
    {
        System.out.println("Hola mi nombre es Russel y soy un guia explorador de la tropa 53 guarida 12" + args[0] + " " + args[1]);
    }
}
